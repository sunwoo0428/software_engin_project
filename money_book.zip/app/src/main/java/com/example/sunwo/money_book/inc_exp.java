package com.example.sunwo.money_book;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class inc_exp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inc_exp);


        final DBExpense dbExpense = new DBExpense(getApplicationContext(), "money_ex.db", null, 1);
        final DBIncome dbIncome = new DBIncome(getApplicationContext(), "money_in.db", null, 1);

        // DB에 저장 될 속성을 입력받는다
        final EditText etExpense = (EditText) findViewById(R.id.et_expense);
        final EditText etExCategory = (EditText) findViewById(R.id.et_ex_category);
        final EditText etIncome = (EditText) findViewById(R.id.et_income);
        final EditText etInCategory = (EditText) findViewById(R.id.et_in_category);

        // 쿼리 결과 입력
        final TextView exResult = (TextView) findViewById(R.id.ex_result);
        final TextView inResult = (TextView) findViewById(R.id.in_result);

        Button btnInsertEx = (Button) findViewById(R.id.btn_insertEx);
        btnInsertEx.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // insert into 테이블명 values (값, 값, 값...);
                String expense = etExpense.getText().toString();
                String category = etExCategory.getText().toString();
                dbExpense.insert("insert into MONEY_EX values(null, " + expense + ", '" + category + "');");

                exResult.setText( dbExpense.PrintData() );
            }
        });

        Button btnInsertIn = (Button) findViewById(R.id.btn_insertIn);
        btnInsertIn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // insert into 테이블명 values (값, 값, 값...);
                String expense = etIncome.getText().toString();
                String category = etInCategory.getText().toString();
                dbIncome.insert("insert into MONEY_IN values(null, " + expense + ", '" + category + "');");

                inResult.setText( dbIncome.PrintData() );
            }
        });


        Button btnDropEx = (Button) findViewById(R.id.btn_dropEx);
        btnDropEx.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbExpense.drop("DROP TABLE IF EXISTS MONEY_EX");
//              tvResult.setText( dbManager.PrintData() );
                dbExpense.createTable("CREATE TABLE MONEY_EX( _id INTEGER PRIMARY KEY AUTOINCREMENT, expense INTEGER, category TEXT);");
                exResult.setText("");
            }
        });

        Button btnDropIn = (Button) findViewById(R.id.btn_dropIn);
        btnDropIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbIncome.drop("DROP TABLE IF EXISTS MONEY_IN");
//              tvResult.setText( dbManager.PrintData() );
                dbIncome.createTable("CREATE TABLE MONEY_IN( _id INTEGER PRIMARY KEY AUTOINCREMENT, income INTEGER, category TEXT);");
                inResult.setText("");
            }
        });

    }
}
