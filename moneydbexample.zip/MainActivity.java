package com.example.sunwo.money_practice;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final DBManager dbManager = new DBManager(getApplicationContext(), "money_ex.db", null, 1);

        // DB에 저장 될 속성을 입력받는다
        final EditText etExpense = (EditText) findViewById(R.id.et_expense);
        final EditText etCategory = (EditText) findViewById(R.id.et_category);

        // 쿼리 결과 입력
        final TextView tvResult = (TextView) findViewById(R.id.tv_result);

        // Insert
        Button btnInsert = (Button) findViewById(R.id.btn_insert);
        btnInsert.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                // insert into 테이블명 values (값, 값, 값...);
                String expense = etExpense.getText().toString();
                String category = etCategory.getText().toString();
                dbManager.insert("insert into MONEY_EX values(null, '" + expense + "', " + category + ");");

                tvResult.setText( dbManager.PrintData() );
                }
           });

        // Update
        Button btnUpdate = (Button) findViewById(R.id.btn_update);
        btnUpdate.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                // update 테이블명 where 조건 set 값;
                String name = etExpense.getText().toString();
                String price = etCategory.getText().toString();
                dbManager.update("update FOOD_LIST set price = " + price + " where name = '" + name + "';");

                tvResult.setText( dbManager.PrintData() );
                }
            });
       // Delete
        Button btnDelete = (Button) findViewById(R.id.btn_delete);
        btnDelete.setOnClickListener(new OnClickListener() {

           public void onClick(View v) {
                // delete from 테이블명 where 조건;
                String name = etCategory.getText().toString();
                dbManager.delete("delete from FOOD_LIST where name = '" + name + "';");

                tvResult.setText( dbManager.PrintData() );
                }
            });

        Button btnRead = (Button) findViewById(R.id.btn_read);
        btnRead.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                // delete from 테이블명 where 조건;

                tvResult.setText( dbManager.PrintData() );
            }
        });
        }
}