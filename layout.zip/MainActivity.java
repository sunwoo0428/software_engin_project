package com.example.layout_practice_2;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

public class MainActivity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        TabHost.TabSpec spec;
        Intent intent;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Resources res = getResources();
        TabHost mTabHost = getTabHost();

        intent = new Intent().setClass(this, tab1.class);
        spec = mTabHost.newTabSpec("tab1").setIndicator("tab1").setContent(intent);
        mTabHost.addTab(spec);

        intent = new Intent().setClass(this, tab2.class);
        spec = mTabHost.newTabSpec("tab2").setIndicator("tab2").setContent(intent);
        mTabHost.addTab(spec);

        intent = new Intent().setClass(this, tab3.class);
        spec = mTabHost.newTabSpec("tab3").setIndicator("tab3").setContent(intent);
        mTabHost.addTab(spec);

        intent = new Intent().setClass(this, tab4.class);
        spec = mTabHost.newTabSpec("tab4").setIndicator("tab4").setContent(intent);
        mTabHost.addTab(spec);

        mTabHost.setCurrentTab(0);
    }
}
