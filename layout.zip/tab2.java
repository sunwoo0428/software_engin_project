package com.example.layout_practice_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tab2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab2);
    }
}
